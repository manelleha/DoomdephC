# DoomdepthC

## Introduction
Doomdepths est un jeu mobile créé par Kacper Jankowski. Dans ce jeu il est question de combattre des
monstres pour obtenir de l'équipement qui permettra par la suite d'avancer dans le jeu, plus l'on va loin dans
le jeu plus les monstres deviennent difficiles à combattre. Ce projet est l'implémentation d'une version allégée de Doomdepths.

## Fonctionnalités principales
1. Génération de monstres aléatoires
2. Attaque du joueur
3. Attaque des monstres
4. Fonctionnement des armes
5. Fonctionnement des armures
6. Sauvegarde
7. Système de Sorts
8. Cartographie

## Fonctionnalités Bonus
1. Système de Niveaux
2. Magasin d'Équipement
3. Quêtes Secondaires
4. Boss de Niveau
5. Événements Aléatoires
6.  Interface interactive

## Etat acuel
Nous avons là, une première version qui permet la création de monstres avec des statistiques aléatoires ainsi 
que la cration d'un joueur avec des statistiques par défaut qui changeront au fil du ou des combats.(Les armes et les armures existent bien mais ne sont pas encore pris en charges)

## Comment procéder ?
A ce stade Il suffit de cloner le repository.



